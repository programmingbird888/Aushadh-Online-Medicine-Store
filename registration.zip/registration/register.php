<?php include('server.php') ?>
<!DOCTYPE html>
<html>
<head>
  <title>Registration</title>
  <link rel="stylesheet" type="text/css" href="style.css">
  <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
</head>
<body>
  <div class="header">
  <a href="aushadh.html"><img src="images/logo.png" alt="aushadh" width="35%"></a><br><br>
  	<h1>**Register**</h1><hr>
  </div>
	
  <form method="post" action="register.php">
  	<?php include('errors.php'); ?>
  	<div class="input-group">
  	  <label for="user"><h2>Username</h2></label>
  	  <input type="text" name="username" placeholder="Enter username" id="user" required>
  	</div>
  	<div class="input-group">
  	  <label for="mail"><h2>Email</h2></label>
  	  <input type="email" name="email"  placeholder="Enter E-mail" id="mail" required>
  	</div>
  	<div class="input-group">
  	  <label for="pass"><h2>Password</h2></label>
  	  <input type="password" name="password_1" placeholder="Enter password" id="pass" required>
  	</div>
  	<div class="input-group">
  	  <label for="cpass"><h2>Confirm password</h2></label>
  	  <input type="password" name="password_2" placeholder="Re-enter password" id="cpass" required>
  	</div>
  	<div class="input-group">
  	  <button type="submit" class="btn" name="reg_user">Register</button>
  	</div>
  	<p>
  		<br><h3>Already a member? </h3>
		  <a href="login.php"><h3>Login here</h3></a>
  	</p>
  </form>
</body>
</html>